import { useState, useRef, useEffect, FormEvent } from "react";

type Role = "user" | "assistant";

interface Message {
  id: number;
  role: Role;
  text: string;
}

interface QuickAction {
  label: string;
  icon: string;
  prompt: string;
}

const QUICK_ACTIONS: QuickAction[] = [
  {
    label: "Planejar aula",
    icon: "📚",
    prompt: "Me ajude a planejar uma aula sobre o tema que eu escolher, com objetivos, atividades e tempo estimado.",
  },
  {
    label: "Planejamento financeiro",
    icon: "💰",
    prompt: "Me ajude a montar um planejamento financeiro simples para a escola, com receitas, despesas e reserva.",
  },
  {
    label: "Organizar tarefas",
    icon: "🗂️",
    prompt: "Me ajude a organizar minhas tarefas da semana por prioridade e prazo.",
  },
  {
    label: "Lançar avaliação",
    icon: "📝",
    prompt: "Me explique passo a passo como lançar as notas de uma avaliação no sistema da escola.",
  },
  {
    label: "Recuperação de alunos",
    icon: "🔁",
    prompt: "Me ajude a montar um plano de recuperação para alunos com dificuldade em um conteúdo.",
  },
  {
    label: "Comportamento da sala",
    icon: "🤝",
    prompt: "Me dê estratégias humanas e positivas para melhorar o comportamento da sala.",
  },
  {
    label: "Fazer a chamada",
    icon: "✅",
    prompt: "Me guie para fazer a chamada da turma de hoje e registrar presenças e faltas.",
  },
  {
    label: "Horário de atividades",
    icon: "🕒",
    prompt: "Me ajude a organizar o horário de atividades da escola para a semana.",
  },
];

const ROLE_HINTS: string[] = [
  "Professores",
  "Coordenação",
  "Secretaria",
  "Direção",
  "Funcionários",
];

function buildReply(input: string): string {
  const text = input.toLowerCase();

  if (text.includes("aula") || text.includes("planej")) {
    if (text.includes("financ")) {
      return "Claro! Para o planejamento financeiro, vamos separar em três partes:\n1. Receitas (mensalidades, verbas, eventos).\n2. Despesas fixas (salários, contas) e variáveis (material, manutenção).\n3. Reserva para imprevistos.\nMe diga o valor aproximado de cada item que eu organizo uma planilha simples para você.";
    }
    return "Vamos planejar a aula com carinho! Me conte:\n• Qual é o tema?\n• Qual a série/ano e quantos alunos?\n• Quanto tempo de aula você tem?\nCom isso, eu sugiro objetivos, uma sequência de atividades e uma forma de avaliar o aprendizado.";
  }
  if (text.includes("financ") || text.includes("orçamento") || text.includes("orcamento")) {
    return "Podemos montar um orçamento simples: liste as receitas do mês, depois as despesas fixas, as variáveis e, por fim, uma reserva de pelo menos 10% para imprevistos. Quer começar pelas receitas?";
  }
  if (text.includes("tarefa") || text.includes("organiz")) {
    return "Ótimo! Me envie a lista de tarefas com o prazo de cada uma. Eu organizo por prioridade (urgente, importante, pode esperar) e monto uma agenda para a semana.";
  }
  if (text.includes("avalia") || text.includes("nota") || text.includes("lançar") || text.includes("lancar")) {
    return "Para lançar as avaliações:\n1. Abra o diário da turma e selecione a avaliação.\n2. Confira a lista de alunos.\n3. Digite as notas e revise antes de salvar.\n4. Alunos que não fizeram a prova podem receber a nota de recuperação depois.\nSe quiser, posso criar uma tabela de correção para você.";
  }
  if (text.includes("recupera")) {
    return "Uma boa recuperação começa com um diagnóstico: identifique o conteúdo em que cada aluno travou. Depois, proponha atividades curtas de revisão, um novo momento de avaliação e um acompanhamento próximo. Quer um modelo de plano?";
  }
  if (text.includes("comport") || text.includes("sala") || text.includes("bagunça") || text.includes("disciplina")) {
    return "Algumas estratégias que costumam funcionar bem:\n• Combine regras claras com a turma, de forma participativa.\n• Elogie comportamentos positivos específicos.\n• Use combinados visuais e pausas curtas de atividade.\n• Converse em particular com alunos que estão tendo dificuldades.\nQuer que eu ajude a criar um quadro de combinados?";
  }
  if (text.includes("chamada") || text.includes("presen") || text.includes("falta")) {
    return "Para fazer a chamada: abra a turma do dia, marque presença ou falta de cada aluno e confirme. Se algum aluno chegou atrasado, registre como atraso. Quer que eu explique como registrar justificativas de falta?";
  }
  if (text.includes("horário") || text.includes("horario") || text.includes("atividade")) {
    return "Vamos organizar o horário! Me diga quantas turmas, quantos períodos por dia e quais atividades fixas existem (recreio, educação física, projetos). Eu monto uma grade equilibrada.";
  }

  return "Oi! Eu sou seu assistente escolar e posso ajudar com planejamento de aulas, planejamento financeiro, organização de tarefas, lançamento de avaliações, recuperação, comportamento da sala, chamada e horários. Sobre o que você quer conversar hoje?";
}

export default function App() {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 0,
      role: "assistant",
      text: "Olá! Eu sou a assistente virtual da escola. Estou aqui para ajudar professores, coordenação, secretaria e direção com o dia a dia. Como posso ajudar você hoje?",
    },
  ]);
  const [input, setInput] = useState<string>("");
  const [isTyping, setIsTyping] = useState<boolean>(false);
  const nextId = useRef<number>(1);
  const listRef = useRef<HTMLDivElement>(null);
  const timers = useRef<number[]>([]);

  useEffect(() => {
    if (listRef.current) {
      listRef.current.scrollTop = listRef.current.scrollHeight;
    }
  }, [messages, isTyping]);

  useEffect(() => {
    return () => {
      timers.current.forEach((t) => window.clearTimeout(t));
    };
  }, []);

  function sendMessage(raw: string) {
    const text = raw.trim();
    if (!text || isTyping) return;

    const userMsg: Message = { id: nextId.current++, role: "user", text };
    setMessages((prev) => [...prev, userMsg]);
    setInput("");
    setIsTyping(true);

    const timer = window.setTimeout(() => {
      const reply: Message = {
        id: nextId.current++,
        role: "assistant",
        text: buildReply(text),
      };
      setMessages((prev) => [...prev, reply]);
      setIsTyping(false);
    }, 700);
    timers.current.push(timer);
  }

  function handleSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    sendMessage(input);
  }

  function handleReset() {
    timers.current.forEach((t) => window.clearTimeout(t));
    timers.current = [];
    nextId.current = 1;
    setIsTyping(false);
    setInput("");
    setMessages([
      {
        id: 0,
        role: "assistant",
        text: "Conversa reiniciada. Como posso ajudar você agora?",
      },
    ]);
  }

  const styles: Record<string, React.CSSProperties> = {
    page: {
      minHeight: "100vh",
      background: "linear-gradient(135deg, #eef4ff 0%, #f8fbf4 100%)",
      fontFamily: "system-ui, -apple-system, Segoe UI, Roboto, sans-serif",
      color: "#1f2937",
      display: "flex",
      justifyContent: "center",
      padding: "24px 12px",
      boxSizing: "border-box",
    },
    container: {
      width: "100%",
      maxWidth: 900,
      display: "flex",
      flexDirection: "column",
      gap: 16,
    },
    header: {
      background: "#ffffff",
      borderRadius: 16,
      padding: "16px 20px",
      boxShadow: "0 2px 10px rgba(0,0,0,0.06)",
      display: "flex",
      justifyContent: "space-between",
      alignItems: "center",
      flexWrap: "wrap",
      gap: 12,
    },
    title: { margin: 0, fontSize: 22, color: "#1d4ed8" },
    subtitle: { margin: "4px 0 0", fontSize: 14, color: "#6b7280" },
    resetBtn: {
      background: "transparent",
      border: "1px solid #d1d5db",
      borderRadius: 10,
      padding: "8px 14px",
      cursor: "pointer",
      fontSize: 14,
      color: "#374151",
    },
    roles: { display: "flex", gap: 8, flexWrap: "wrap" },
    roleTag: {
      background: "#e0e7ff",
      color: "#3730a3",
      borderRadius: 999,
      padding: "4px 10px",
      fontSize: 12,
    },
    chatBox: {
      background: "#ffffff",
      borderRadius: 16,
      boxShadow: "0 2px 10px rgba(0,0,0,0.06)",
      display: "flex",
      flexDirection: "column",
      height: "60vh",
      minHeight: 360,
      overflow: "hidden",
    },
    messages: {
      flex: 1,
      overflowY: "auto",
      padding: 16,
      display: "flex",
      flexDirection: "column",
      gap: 12,
    },
    rowUser: { display: "flex", justifyContent: "flex-end" },
    rowAssistant: { display: "flex", justifyContent: "flex-start" },
    bubbleUser: {
      background: "#2563eb",
      color: "#ffffff",
      borderRadius: "16px 16px 4px 16px",
      padding: "10px 14px",
      maxWidth: "75%",
      whiteSpace: "pre-wrap",
      lineHeight: 1.5,
      fontSize: 15,
    },
    bubbleAssistant: {
      background: "#f3f4f6",
      color: "#1f2937",
      borderRadius: "16px 16px 16px 4px",
      padding: "10px 14px",
      maxWidth: "75%",
      whiteSpace: "pre-wrap",
      lineHeight: 1.5,
      fontSize: 15,
    },
    typing: {
      fontSize: 14,
      color: "#6b7280",
      fontStyle: "italic",
    },
    quickWrap: {
      borderTop: "1px solid #e5e7eb",
      padding: 12,
      display: "flex",
      gap: 8,
      flexWrap: "wrap",
    },
    quickBtn: {
      background: "#f9fafb",
      border: "1px solid #d1d5db",
      borderRadius: 999,
      padding: "6px 12px",
      cursor: "pointer",
      fontSize: 13,
      color: "#111827",
    },
    form: {
      borderTop: "1px solid #e5e7eb",
      padding: 12,
      display: "flex",
      gap: 8,
    },
    input: {
      flex: 1,
      border: "1px solid #d1d5db",
      borderRadius: 12,
      padding: "10px 14px",
      fontSize: 15,
      outline: "none",
    },
    sendBtn: {
      background: "#2563eb",
      color: "#ffffff",
      border: "none",
      borderRadius: 12,
      padding: "10px 18px",
      fontSize: 15,
      cursor: "pointer",
    },
    disclaimer: {
      fontSize: 12,
      color: "#6b7280",
      textAlign: "center",
      margin: 0,
    },
  };

  return (
    <div style={styles.page}>
      <div style={styles.container}>
        <header style={styles.header}>
          <div>
            <h1 style={styles.title}>Chatbot Escolar IA</h1>
            <p style={styles.subtitle}>
              Um apoio humano e interativo para toda a comunidade escolar
            </p>
            <div style={styles.roles}>
              {ROLE_HINTS.map((role) => (
                <span key={role} style={styles.roleTag}>
                  {role}
                </span>
              ))}
            </div>
          </div>
          <button type="button" style={styles.resetBtn} onClick={handleReset}>
            Nova conversa
          </button>
        </header>

        <section style={styles.chatBox} aria-label="Conversa com a assistente">
          <div style={styles.messages} ref={listRef}>
            {messages.map((m) => (
              <div
                key={m.id}
                style={m.role === "user" ? styles.rowUser : styles.rowAssistant}
              >
                <div
                  style={
                    m.role === "user" ? styles.bubbleUser : styles.bubbleAssistant
                  }
                >
                  {m.text}
                </div>
              </div>
            ))}
            {isTyping && (
              <div style={styles.rowAssistant}>
                <div style={styles.typing}>A assistente está digitando...</div>
              </div>
            )}
          </div>

          <div style={styles.quickWrap}>
            {QUICK_ACTIONS.map((action) => (
              <button
                key={action.label}
                type="button"
                style={styles.quickBtn}
                onClick={() => sendMessage(action.prompt)}
                disabled={isTyping}
              >
                {action.icon} {action.label}
              </button>
            ))}
          </div>

          <form style={styles.form} onSubmit={handleSubmit}>
            <input
              style={styles.input}
              type="text"
              value={input}
              placeholder="Escreva sua mensagem aqui..."
              onChange={(e) => setInput(e.target.value)}
              aria-label="Mensagem"
            />
            <button
              type="submit"
              style={styles.sendBtn}
              disabled={isTyping || !input.trim()}
            >
              Enviar
            </button>
          </form>
        </section>

        <p style={styles.disclaimer}>
          A assistente oferece sugestões de apoio. Confira sempre as informações antes de tomar decisões oficiais.
        </p>
      </div>
    </div>
  );
}
